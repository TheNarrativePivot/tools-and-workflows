# Competitor and source tracking

Manually curated. When a tracked voice publishes something relevant (LinkedIn post, newsletter issue, shareable asset), paste or summarize it into their file, newest entries at the top. Claude reads these during Stage 2 and weekly idea generation; Claude treats absence in these files as "not in the hub," never as "they haven't said it."

## Competitors (compete for the same reader's attention)

| Voice | File | Where they publish |
| --- | --- | --- |
| Fletch PMM (Anthony Pierri & Rob Kaminski) | `fletch-pmm.md` | LinkedIn (primary), monthly newsletter at fletchpmm.com/newsletter |
| Emily Kramer (MKT1) | `emily-kramer-mkt1.md` | MKT1 newsletter, templates and resources |
| Rory Woodbridge | `rory-woodbridge.md` | productmarketer.substack.com |
| April Dunford | `april-dunford.md` | aprildunford.substack.com |

## Sources (aggregators, not competitors)

Product Marketing Alliance (productmarketingalliance.com) is a SOURCE, not a competitor. Material found via PMA goes into `sources-pma.md`. Stage 2 never asks "what is PMA not saying"; PMA entries are raw material for gaps, audience questions, and hub signals.

## Entry format (all files)

```
## YYYY-MM-DD | [type: LinkedIn post / newsletter / asset / article]
Link: [url]
Topic: [one line]
Their claim/frame: [summary or short excerpt]
Why saved: [what caught Neera's eye]
```
