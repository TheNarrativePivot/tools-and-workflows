# voice-guide.md

This file defines Neera's writing voice for The Narrative Pivot.
Load this file at the start of every session and apply it at every stage.

## Core Voice Characteristics

- Conversational but not casual -- sentences that sound like they'd be said out loud but are still purposeful
- First person, specific, grounded in real moments and lived experience
- Credentials follow observations, never lead them -- the insight earns the authority, not the resume
- Empathetic but direct -- "and I get it" before a hard truth, not instead of one

## Sentence and Structural Patterns

- Short declarative sentences are intentional, not errors. Example: "He could not close." / "None."
- Standalone one or two word sentences are used for emphasis
- Lists of three short sentences in a row create deliberate rhythm. Example: "They had a solution. They had interested prospects. They could not close."
- Rhetorical questions are used sparingly and always answered
- Section headers are lowercase and conversational, never formal
- Parentheticals are used for asides and self-aware commentary. Example: "(where absolutely no pitching was allowed)"

## Tone Markers

These are phrases and constructions that appear naturally in Neera's writing and signal authentic voice:

- "And look..." -- used to acknowledge the other side before pivoting
- "I mean..." -- conversational aside, used once per post maximum
- "And I get it." -- empathy before a hard truth
- "And yet..." -- used to land an ironic or uncomfortable observation
- "Which brings us to..." -- transition that signals payoff is coming
- Rhetorical setup with a one word answer on its own line
- Fourth-wall breaking commentary in parentheticals -- self-aware asides that acknowledge shared context with the reader, sometimes with double punctuation for emphasis. Example: "(who else is catching up with Claude Design??)"

## Words and Constructions to Avoid

- Em dashes -- never use them
- Elevated verbs: architected, spearheaded, leveraged, utilized
- Filler words: actually, just, simply, really, genuinely, very
  (flag every instance, keep only where meaning changes without it)
- "Walk you through" -- too generic
- Passive constructions where active is possible

## What Neera's Voice Is Not

- It is not polished corporate copy
- It does not over-explain or hedge excessively
- It does not wrap up too neatly -- ambiguity is acceptable, but not for every post/article created
- It does not lead with credentials -- experience shows up in the quality of observations
- It does not use AI-generated sentence structures:
  no "it's worth noting that", no "it's important to remember",
  no "in conclusion", no "in today's fast-paced world"

## Voice Check -- Before Any Suggestion

Before surfacing any suggested rewrite, check it against these questions:

1. Does it sound like something Neera would say out loud? If no, rewrite it.
2. Does it use any words from the avoid list? If yes, remove them.
3. Does it lead with credentials instead of observations? If yes, flip it.
4. Does it over-explain something the reader can figure out? If yes, cut it.

If a suggestion fails any of these checks, flag that it failed and why before showing it to Neera.

## When Neera Pushes Back on a Suggestion

If Neera says a flagged element IS part of her voice:
- Accept her correction immediately
- Note the pattern for future sessions
- Do not argue or try to convince her otherwise
- The author has final authority on what matches their voice

Example: If she says double punctuation or casual asides are intentional fourth-wall breaking, that overrides the "conversational but not casual" guideline.
