# You don't have a messaging problem. You have a listening one.

Subtitle: What my conversations at three local tech events taught me about why great products struggle to grow.
Published: March 16, 2026 | Pillar: Messaging
Source: https://thenarrativepivot.substack.com/p/you-dont-have-a-messaging-problem

---

Most event recaps focus on the speakers. The frameworks, the slides, the keynote takeaways. And look, those definitely have their place. But some of the most useful conversations I've had in my career have happened outside the meeting room, by the bar, or while waiting for the next session to start.

Over the last month, I attended a few local tech events, including a Claude Code Meetup, Startup Drinks (where absolutely no pitching was allowed), and a gathering on how to create AI agents with OpenClaw. Good energy, cool products, and wicked smart people building real things. But the most interesting conversations weren't the ones happening onstage.

They were with *regular attendees*.

Founders at various stages. Some with early traction, some with a pipeline they couldn't close. And almost every single one of them was wrestling with the same thing.

### the conversation that stuck with me

One of the most notable examples was at Startup Drinks where I spoke with a founder who'd built something genuinely novel. They had identified a real, measurable pain point in the wholesale distribution of industrial materials vertical. The kind of problem where companies are losing money on a regular basis. They had a solution. They had interested prospects.

They could not close.

Here's the common challenge they faced: the companies they were pitching to already knew about the problem. So it wasn't a discovery issue. It was that they had accepted the problem as a matter of fact and treated it as a cost of doing business.

So when this founder walked in leading with "our product will help you recover lost revenue," the response was: "we know, but it's not really worth disrupting our operations over."

They didn't have a messaging problem. They had a listening problem. Specifically, they hadn't yet dug deep enough into what would actually make these legacy companies move.

### sound familiar?

This isn't just an early-stage founder problem. It shows up at every size of business, in every vertical. After 8+ years in B2B marketing (with half of it in programmatic advertising), I've sat on both sides of these conversations enough times to recognize a pattern when I see one.

For a while, our go-to pitch was some variation of "unlock more ad revenue" or "optimize your monetization strategies with us."

It wasn't wrong. We genuinely did that. It just wasn't landing.

Not because our buyers didn't care about revenue. I mean, they did, but when you're talking to a Programmatic Manager or a CRO Partnership Manager, making more money is *table stakes*. Every vendor in their inbox promised some spin on generating more revenue. That pitch had simply become white noise.

What actually broke through was when we stopped stating the outcome they already knew they wanted and started speaking to something more specific: the thing they were quietly worried about losing in the process. For our audience, that was their end user's web experience. They didn't want to generate more revenue at the cost of a worse online experience for their users. When we reframed our messaging around that tension, the conversations changed.

We'd stopped pitching. We'd started listening. And deals that had stalled now started to move.

### your messaging speaks to a company but your buyer is a person

It's not the worst strategy in the world for your messaging to lead with ROI or revenue. It's just what everyone else says.

"Stop leaving money on the table."

"Drive more revenue with *[insert-super-amazing-very-unique-product-name-here]*."

"Get more time back in your week."

Sidebar: your messaging isn't different just because it mentions AI. Everyone's building their own GPT or AI wrapper. It's becoming the bare minimum to offer an AI-native product "that automates your workflow and lets you scale indefinitely."

Your prospect is hearing some version of these from at least five other vendors. Some aren't even your direct competitors. And after a while, it all starts to sound the same because nobody stopped to listen long enough to say something different.

#### so what's your buyer actually thinking about?

They're someone with a manager they report to, a list of priorities they're being measured on this quarter, and a very specific set of things they are trying not to break. Company-level ROI doesn't speak to any of that. The prospect you're pitching to isn't sitting around constantly wondering about generating revenue.

They're the Head of Marketing wondering why last quarter's campaigns created traffic but not pipeline, and how they're going to justify the budget they just fought to keep.

They're the VP of Sales debating whether adding another AI tool to the stack is going to help close that stalled enterprise deal or just create more noise for their team.

They're the Director of Ops calculating whether the onboarding timeline is going to blow up their quarter before it helps it.

And you can only know any of that if you've *listened* first. And yet, most pitches skip that part entirely.

### the quick check you can do right now

Take your homepage headline, your sales pitch, your LinkedIn outreach message. Now swap your product name for a competitor's. Does anything break?

If your messaging holds up just fine, then you don't have a differentiation problem. You have a communication problem.

The noise in your buyer's inbox isn't just volume. It's sameness. Everyone is promising the same outcomes in slightly different flavours. The way out isn't just a new headline. It's a more specific understanding of what your buyer needs to hear.

### questions you need to start asking

If your company already has customers or an active pipeline, you already have access to the research you need. You're just not asking the right things.

Have your Customer Success and Sales teams start implementing these questions: what would you be doing if our product didn't exist? Who would you be working with instead? If a competitor exists, why aren't you using them today?

And I get it. These are hard questions to ask. But it's information you need to understand, even if it's unsettling to hear.

Those answers will tell you more about your actual value than any internal positioning exercise ever will.

When you're getting on early calls with interested prospects, try this. Before you launch into your pitch, ask them one question. "What caught your attention about our product today?" Then stop talking. Let them go. In my time sitting in on the receiving end of pitches and sales calls, I can count on one hand the number of times a BDR or AE asked me why I agreed to the call.

None.

After a bit of awkward small talk, everyone immediately opened their deck and started presenting. That question will tell you more about your actual value than you've probably heard before.

### the hardest question underneath it all

Once you've done the listening, there's an exercise I want you to try. It's the one I shared with founders across all three events. Simple, a little humbling, but worth it.

Look at your product as objectively as you can and ask yourself: why does my customer *actually* care about this? Not why do they like it. Not what problem does it solve. Why do they care?

Then take your answer and ask it again. Why does that matter to them?

Keep going until you've stripped out all the technical language, the industry jargon, the AI features, the buzzwords. Keep going until you hit something that could be said to a non-expert and still land.

I'll be candid. A few founders seemed tense, some were a bit defensive too. They explained that all the context and background was necessary to make their value known. That resistance was the exercise doing its job.

You'll know you're there when the answer feels almost too simple. When it sounds like something a human being would actually say to another human being. Something that doesn't take five minutes of context to explain.

Sometimes this exercise confirms what you already knew. Sometimes it reveals that the value you've been leading with isn't the value your customers care about. Either outcome is useful. The first gives you the ability to simplify. The second gives you a chance to refocus before you spend another six months pitching the wrong thing.

Neither is comfortable. But both are better than the alternative.

---

**about the narrative pivot**

I'm Neera, a product marketer with 8+ years helping early-stage and growth companies get their positioning and messaging right. I started the narrative pivot around the simple belief that great messaging doesn't begin with your copy. It begins with getting your team aligned before a single word gets written.
