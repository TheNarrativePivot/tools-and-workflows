# the homepage audit: what B2B SaaS gets wrong every time

Subtitle: and the 3 questions to fix it
Published: June 11, 2026 | Pillar: Positioning
Source: https://thenarrativepivot.substack.com/p/the-homepage-audit-what-b2b-saas
Note: images and framework tables referenced below live in the published post.

---

Have you ever asked your sales reps, your product managers, maybe your team leads, what your company *actually* does?

You'll probably get three different answers. And none of them are exactly wrong.

They're just different.

This happens more often than you'd think. It's also why your homepage isn't converting.

Here's what happens. Marketing is tasked with rewriting the homepage copy, and it starts good. It's pain-point-focused, written for your primary buyer, value-based, the works.

Then it has to get approved.

Sales wants it to speak to enterprise buyers. Product wants the new feature mentioned. Someone from the C-suite wants it to "sound bigger" (*they can never be specific, can they?*).

Nobody's asking for anything unreasonable, but by the time the homepage goes live, it's been chipped away at so many times that the end result tries to speak to everyone. Which means it now speaks to no one.

Visitors land, skim your page, then bounce. Not because they disagree with what you offer, but because they can't even tell what it is or whether it's for them.

That's why I spent the last week auditing 30+ B2B SaaS homepages. I'm sharing what I found and the simple framework I use to figure out whether a homepage is actually working or not.

## what most homepages don't answer

When I review a homepage, I ask myself 3 simple questions.

**1. What exactly is this product or service?**

Are you a category disruptor, a consolidation of multiple tools, an alternative to the status quo?

**2. Who's it for?**

Your target buyer should see themselves in your hero section. Not buried halfway down the page.

**3. Why should your target audience care?**

This is what I call the **transformation moment**. The before-after shift your product creates. Not just calling out your features or benefits. I'm talking about the changed state from your buyers' current struggle to the outcome they want.

Most homepages answer none of these questions in the hero section. Maybe they're found halfway down the homepage. Usually by the end.

Here's what this framework looks like across 3 real examples.

## example 1: hex.tech, grade B

Headline: "The AI Analytics Platform where trust meets insight." This is nearly identical to the positioning for many products in the business intelligence (BI) industry (see Amplitude).

The subheadline reads: "Finally, anyone can get data insights grounded in the facts of their business. Hex has a flexible approach to context that earns trust without slowing you down."

This is still generic. I could replace 'Hex' with Tableau or Looker and the sentence would still work.

There's no competitor differentiation.

### what works

They do eventually highlight what status quo looks like, "juggling separate notebooks, BI tools, and ad-hoc Slack requests," stating that they're not just a notebook or BI tool, but a unified platform replacing multiple tools.

### what can be better

Hex buried the answers to all 3 questions under generic language and AI buzzwords. The consolidation story, the thing that makes Hex valuable, is there, but you have to scroll down to the bottom of their page to find it.

If your homepage makes people work to figure out what you do, who you're for, and why they should care, you've lost them.

### the neera rewrite

If I were their product marketer, I'd lead with their primary buyer and their pain point.

**New headline**: Your data team shouldn't be a factory for ad-hoc requests.

**New subheadline**: Unify fragmented data across notebooks, BI tools, and Slack in one workspace. Run the analysis once, let everyone from engineering to marketing now self-serve effortlessly.

This version does 3 things the current hero doesn't. It names the specific audience (data team), names the exact tools (notebooks, BI tools) the target audience can expect to be consolidated, and states the transformation (now self-serve effortlessly).

Don't tell me it's AI-powered. Tell me what the end result is and how it's better than the status quo.

Overall, Hex scores a grade B. Their FAQ does a lot of the work. If they dispersed that information across their homepage rather than at the end, they could have scored higher.

## example 2: statsig.com, grade C

First off, I really do love the headline: "Measure what ships. Ship what matters." It's short but memorable.

But the subheadline, "Test how each release - from features to AI-powered experiences - lands with customers, so you can protect trust and optimize at the speed of AI" undermines it with buzzword-heavy copy (*what does optimize at the speed of AI even mean??*).

It also fails to identify the primary buyer or the pain point Statsig aims to solve.

### what works

Prospects can install the Statsig SDK to run their first experiment and test the tool out for themselves. In a time where AI can succinctly compare B2B products for your buyers, giving them the ability to test your service independently without a paywall will help set you apart from your competitors.

### what can be better

On top of a subheadline with too many AI buzzwords, there's no competitive frame of reference or transformation moment. Nothing that speaks to the buyer that says, "and here's why you should switch to Statsig." This is a website with a strong foundation, but weak execution. They have the right ingredients, but didn't assemble them into a clear, buyer-specific message.

### the neera rewrite

I'd actually leave their headline as is. It's concise, and we can use the subheading to identify the primary buyer.

**New subheadline**: Product owners should be able to scale experiments without overloading engineering. Feature flags, A/B tests, and analytics, all in one platform. Decouple code from releases and ship with confidence.

By identifying the primary buyer in the subheadline, web visitors will instantly understand who this product is for.

Statsig's homepage tries to speak to product managers, engineers, and data science teams. The result? Generic language that resonates with no one. My rewrite picks product owners. The people who feel the burn of slow experiment cycles.

Statsig's homepage mirrors a common SaaS copy format I see often. Mention the features, your case studies, a bit about pricing, some fancy logos, and some well-meaning proof points. But it doesn't answer the question: why them? Why Statsig? And for that, they get a C.

## example 3: semgrep.dev, grade A

"Code Security for Builders" semi-identifies the primary buyer. The subheadline clarifies it further. It clearly speaks to someone with a developer/engineering background as it highlights catching and flagging vulnerabilities and unifying SAST, SCA, and secrets.

I'm not their target audience, so I don't expect to immediately understand their copy. But they've done the best job compared to the previous examples in speaking to their target market.

This is further validated by their logos section, "Loved by leading engineering teams." *See? I was in the right range.*

My favourite part about this homepage is that it has a dedicated **Why Semgrep** section.

It identifies their primary buyer and includes that transformation point we keep talking about, "giv[ing] security teams visibility, control, and confidence." A transformation point doesn't have to take up a whole section or sound bigger than what it really is.

It just needs to clearly outline what your service does differently.

Are you replacing something? Making it better than the status quo? Offering something competitors don't?

I would have loved it if they included a video demo of a security developer using their product rather than a static image so their target audience could easily see how they could use Semgrep themselves, but no one's perfect.

### what works

Semgrep does a great job solving what most B2B SaaS businesses get stumped with. Speaking to too many ICPs at once. They easily resolve this with their "Built for every role" section that clearly labels each ICP and what value they'd individually derive from working with Semgrep.

It'd be better if they moved this up higher, as the "builders" in their headline covers all 3 ICPs, but it's still helpful to have on the homepage.

### what can be better

The homepage is incredibly technical.

It's clear that they know who they're speaking to, and who they're not. With that being said, for a buyer type like developers who don't have much patience for corporate jargon, leading your first feature callout with "Empower invention without friction," feels like a misstep. Does anyone really talk about empowering invention?

If you're stumped for copy, look into your customer feedback and win/loss interviews to see what your own users are saying. Semgrep could replace their first feature headline with, "Find real vulnerabilities, skip false alarms."

### the neera rewrite

While the subheadline helps to further clarify the primary buyer, it's a bit of a word jumble. Too many ideas competing for attention.

"Catch, flag, and fix real vulnerabilities before they ship, powered by security that learns as you build." This is in line with the rest of the homepage, but what does "powered by security" mean?

"Unify SAST, SCA, and secrets scanning into one platform built for today's software era." Calling out SAST and SCA helps to speak to the right target audience and reference what category their primary buyer is in, but again, what does "today's software era" mean?

**New subheadline**: Find real vulnerabilities, ignore the noise, fix before shipping. Unify SAST and SCA into one platform and see 80%+ fewer false positives with significantly faster triage and remediation.

I kept the language that speaks to the industry to ensure the target buyer sees themselves in the copy, while leaning on some of their best metrics. Developers particularly don't care for marketing fluff, so best to show them what you can do right from the start.

Notice the pattern across all 3 examples?

Hex buried their differentiation. Statsig skipped it entirely. Semgrep led with it. The difference between the grades comes down to whether you answer the 3 questions up front, or make your visitors hunt for answers.

## audit takeaways

When evaluating your homepage copy, make sure it has answered the following:

- What does your product/service do?
- Who is your target audience?
- Why should they care?

And if you're stuck on copy ideas, go through your call transcripts.

There are tons of gold nuggets for copy inspiration lying right in front of you. When addressing your "why customers should care," always think about that transformative moment. Spell it out for your buyers (so ChatGPT and Gemini can pick it up when comparing you to your competitors).
