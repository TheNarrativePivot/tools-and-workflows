# editorial.md

Stage 5 and Stage 9 of The Narrative Pivot workflow.
Always load voice.md before running this skill.

## Purpose

To evaluate the structural integrity of a full draft before 
any line editing begins. This stage looks at the whole post 
as a piece of writing -- not individual sentences or word choices.

This stage does NOT fix language, suggest rewrites, or 
flag grammar. That is Stage 5.
It produces structural feedback only.

## Input

Neera's full draft, plus any external feedback (e.g., from 
Gemini or another tool) gathered after Stage 4.

If external feedback accompanies the draft:
- Note points that overlap with your structural assessment
- Evaluate whether the external feedback identifies 
  structural issues beyond the six checks here
- Surface overlapping issues together to avoid 
  redundant flags
- Do not treat external feedback as authoritative -- 
  assess it against the structural checks below

## What Claude Does at This Stage

1. Read the full draft without stopping to flag language issues
2. Assess the draft against the six structural checks below
3. Flag every structural issue with the specific location 
   in the draft
4. Do NOT rewrite anything
5. Do NOT comment on word choice, grammar, or phrasing
6. Produce a clear editorial summary at the end

## The Six Structural Checks

**Check 1: Target audience clarity**
Is it clear within the first two paragraphs who this post
is for? Would a B2B SaaS founder or business leader
self-identify before the end of the hook?

Flag if:
- The hook takes more than two paragraphs to signal
  the target reader
- The post could be mistaken for content written for PMMs
  rather than founders or business leaders
- The problem setup reflects an outdated version of the
  reader's reality (e.g., framing AI as an emerging technology
  when the reader has already adopted it, or focusing on
  "adoption pressure" when the real issue is "effective usage")

When the target reader's landscape shifts (early adoption →
strategic usage, for example), the intro must shift with it
or it will feel dated even if published weeks later.

**Check 2: Thesis clarity and consistency**
Is the core thesis stated explicitly somewhere in the post?
Does it reappear in some form in every major section?

Flag if:
- The thesis is never stated plainly
- The thesis disappears after the opening story and 
  doesn't reappear until the ending
- The thesis is buried inside a longer paragraph where 
  it won't land as a standalone moment

**Check 3: Section redundancy**
Is any section doing the same job as another section?
Are any two consecutive paragraphs making the same point
in different words?

Flag if:
- Two sections have the same job
- The same idea appears more than once without
  adding new dimension
- A section header and its opening line say the same thing

Note: Neera often self-diagnoses redundancy before you flag it.
If she's noted in comments that a section "feels redundant" or
questions "do we need this?" validate her instinct and recommend
cutting or consolidating.

**Check 4: Hook and framework alignment**
Does the hook make a promise that the framework section 
delivers on? Is there a clear line from what the hook 
sets up to what the actionable section provides?

Flag if:
- The hook sets up a question the post never answers
- The framework section delivers something different 
  from what the hook implied
- The transition from story to advice feels abrupt 
  or unearned

**Check 5: Ending resolution**
Does the ending close any open narrative thread from 
the hook? Does it feel honest rather than tidy?

Flag if:
- The hook introduced a specific person, moment, or 
  story that the ending never returns to
- The ending wraps up too neatly and loses the 
  honest tension built earlier
- The ending introduces a new idea that wasn't 
  set up earlier in the post

**Check 6: Voice consistency**
Does the post sound like one person wrote it throughout?
Are there sections that drift into corporate language, 
generic PMM advice, or over-polished copy?

Flag if:
- Any section sounds like it could have been written 
  by a different person
- Credentials are leading an argument instead of 
  following an observation
- Any section uses PMM insider language without 
  translating it for a founder audience

## Editorial Summary Format

After running all six checks, produce a summary in this format:

---
**Overall structural assessment:**
(One paragraph -- is the post structurally sound or does it 
need significant work before line editing?)

**Checks passed:** (list)

**Checks flagged:** (list each with specific location and 
a one sentence description of the issue)

**Priority fix:**
(The one structural issue that most needs to be addressed 
before moving to Stage 5. If the post needs to go back to 
Stage 3, say so explicitly.)
---

## Stage 9 Usage

When used in Stage 9 as a final pass, run only these checks:
- Thesis clarity and consistency
- Hook and framework alignment
- Ending resolution

Skip redundancy and voice checks at Stage 9 -- those should 
have been resolved in earlier stages. If they haven't been, 
flag that Stages 6 and 7 may need to be revisited.

## Output

A completed editorial summary with flagged issues and 
a priority fix. No rewrites. No line edits.
The draft goes back to Neera before moving to Stage 6.