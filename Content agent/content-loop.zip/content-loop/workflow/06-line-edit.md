# line-edit.md

Stage 6 of The Narrative Pivot workflow.
Always load voice.md before running this skill.

## Purpose

To identify language-level issues in a revised draft after 
Stage 5 structural feedback has been addressed. This stage 
works at the sentence and word level, not the structural level.

This stage does NOT rewrite anything.
It flags issues and identifies their location.
Rewrites happen in Stage 7.

## Input

Neera's revised draft after Stage 5 editorial pass.

## What Claude Does at This Stage

1. Read the full draft and flag every language issue 
   listed below
2. Note the specific location of each issue 
   (quote the relevant phrase or sentence)
3. Do NOT suggest fixes at this stage -- 
   that is Stage 6
4. Produce a flagged issues list grouped by category
5. End with a count of total flags by category

## Filler Word Check

Search the entire post for every instance of these words.
Flag every one with its location:

- actually
- just
- simply
- really
- genuinely
- very
- quite
- somewhat
- a bit
- kind of
- sort of

For each flagged instance note:
- Is the word changing the meaning of the sentence?
- Or is it softening a statement that would be 
  stronger without it?

Keep only instances where removing the word changes 
the meaning. Flag all others for cutting.

## Repetition Check

**Word repetition within a paragraph:**
Flag any word that appears more than twice in the 
same paragraph, excluding common words like 
the, and, a, is, it, in, of, to.

**Word repetition across the full post:**
Flag any non-common word that appears more than 
four times across the full post.

**Sentence structure repetition:**
Flag any two consecutive sentences that open 
with the same word or phrase.

**Idea repetition:**
Flag any two paragraphs that make the same point 
in different words without adding new dimension.

## Double Negative Check

Flag any sentence containing two or more negatives.
Example: "The reason they weren't buying wasn't 
because they didn't understand the problem."

Note the location and suggest it needs simplifying 
in Stage 6.

## Number Consistency Check

Identify every number in the post.
Flag any inconsistency in how numbers are treated:
- Numbers one through nine should be spelled out
- Numbers 10 and above should use numerals
- Exception: "8+ years" in professional credential
  context is acceptable as a numeral
- Exception: Ranges in metrics/measurements (e.g., "1-2 conversations
  per week," "4-8 interviews per month") may use numerals for clarity
  even when under 10

## Tense Consistency Check

Read the post for tense shifts.
Flag any unintentional shift between past and 
present tense within the same section.

Note: present tense used within a past narrative 
to describe something that remains true is 
acceptable and should not be flagged.

## Grammar and Punctuation Check

Flag the following:
- Subject-verb agreement errors
- Apostrophe errors in possessives
- Comma splices
- Missing commas before lists introduced 
  with "including"
- Periods inside or outside quotation marks 
  used inconsistently
- Sentences ending in prepositions where 
  it creates awkwardness
- Fragments that appear unintentional 
  (intentional fragments for rhythm are fine -- 
  use voice.md to distinguish)

## Section Header Check

For every section header, check:
- Does the opening line of that section restate 
  what the header already said?
- Do any two section headers across the post 
  say the same thing?

Flag both if found.

## PMM Insider Language Check

Flag any term that a founder or business leader 
would not immediately understand without context:

Watch list:
- positioning
- messaging
- go-to-market / GTM
- ICP
- PMM
- value proposition
- product-market fit
- sales enablement
- competitive intelligence
- north star metric

For each flagged term note whether it has been 
translated into plain language in context or 
whether it is being used without explanation.

## Factual Accuracy Check

Search the draft for any claim that could be verified 
against external sources. Flag any assertion that:

- States what AI can or cannot do 
  (e.g., "AI can't generate X" or "AI eliminates Y")
- Cites a statistic, data point, or percentage 
  without a source
- Makes a specific claim about a named company, 
  product, or person that Neera did not include 
  in her original input
- Asserts market conditions or buyer behavior as fact
  without attributing them to research or experience

Do NOT flag:
- Observations from Neera's own experience
- General arguments she is making as the author
- Claims that are clearly framed as her perspective

For each flagged claim note:
- The specific assertion
- What would need to be verified or softened
- Whether removing or qualifying the claim 
  would weaken the argument

## Flagged Issues Format

Produce the output in this format:

---
**FILLER WORDS**
- "[quoted phrase]" -- location -- keep or cut recommendation

**REPETITION**
- "[quoted word or phrase]" -- location -- type of repetition

**DOUBLE NEGATIVES**
- "[quoted sentence]" -- location

**NUMBER CONSISTENCY**
- "[quoted instance]" -- location -- what the fix should be

**TENSE CONSISTENCY**
- "[quoted phrase]" -- location -- nature of the shift

**GRAMMAR AND PUNCTUATION**
- "[quoted phrase]" -- location -- issue type

**SECTION HEADERS**
- "[quoted header and opening line]" -- location -- issue type

**PMM INSIDER LANGUAGE**
- "[quoted term]" -- location -- translated or untranslated

**FACTUAL ACCURACY**
- "[quoted claim]" -- location -- what needs verification or softening

**TOTAL FLAGS BY CATEGORY:**
Filler words: #
Repetition: #
Double negatives: #
Number consistency: #
Tense consistency: #
Grammar and punctuation: #
Section headers: #
PMM insider language: #
Factual accuracy: #
---

## Output

A complete flagged issues list grouped by category 
with a total count. No rewrites. No suggestions.
The flagged list goes to Stage 7 for suggestion pass.