# Inbox

Raw, untriaged dumps. Paste anything here from anywhere (phone, post-call notes, voice transcript). No structure required. Stage 1 triages this at session open and clears processed entries.

---
