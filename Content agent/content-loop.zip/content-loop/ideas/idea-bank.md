# Idea Bank

Triaged idea cards. Card format lives in workflow/01-capture.md.
Statuses: inbox / developing / brief-ready / drafted / published / archived.

---
