# Status

- Post: [title]
- Idea card: [link/anchor in idea-bank.md]
- Current stage: [1-10]
- Google Doc: [link, from stage 4]
- Next action: [one line]
- Last touched: [date]
