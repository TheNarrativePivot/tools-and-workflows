# Status

- Post: the homepage audit: what B2B SaaS gets wrong every time
- Published: 2026-06-11
- Current stage: published (pre-dates the loop; no draft-v1 baseline, so no stage 10 postmortem)
- Note: feedback-received.md from this post seeded the initial swipe file.
