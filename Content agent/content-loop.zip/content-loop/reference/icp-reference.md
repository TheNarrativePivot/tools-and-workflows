__THE NARRATIVE PIVOT__

__ICP Reference__

__Who I work with__

Growth\-stage B2B SaaS companies where Marketing and Sales are visibly misaligned — content exists, customers exist, but internal opinions are drowning out the customer's voice and deals are showing it\.

__AT A GLANCE__

__Category__

B2B SaaS

__Headcount__

50\-200 employees

__Stage__

Post\-traction, Series A to C

__Geography__

Canadian tech ecosystem \(primary\), B2B SaaS broadly

__Buyer energy__

M2 — already doing the work internally, doing it badly

__THE TRIGGER MOMENT__

My client is not looking for someone to explain why messaging matters\. They already know\. The moment I enter is specific:

__Sales and Marketing aren't telling the same story__

Reps go off\-script\. Decks don't match what sales actually says in the room\. Everyone has a different elevator pitch\.

__Content exists but isn't being used__

Marketing built the assets\. Sales ignores them\. Or worse, sales builds their own because what exists doesn't work\.

__Nobody can say what the product does in one sentence__

Ask five people and get five answers\. The website doesn't help\. Prospects disengage before the demo\.

__Internal opinions are drowning out the customer's voice__

Everyone has a theory about positioning\. Nobody has talked to customers systematically\.

__SUBMERGED ATTRIBUTES \(THE REAL ICP\)__

__Trigger event__

Sales and Marketing are visibly misaligned\. The gap is showing up in deals\.

__Situational context__

They have customers and internal knowledge\. What's missing is a mechanism to surface and translate the voice of the customer into something GTM can act on\.

__Buyer awareness__

They know they have a problem\. They frame it as a messaging or sales enablement problem\. They don't yet know it's a listening problem\.

__Jobs to be done__

Get Marketing and Sales telling the same story, sourced from what customers actually say, so deals move faster and content gets used\.

__THE BUYER SLIDING SCALE__

Title changes by company size, but the trigger and JTBD are identical across all three\.

__50\-100 EMPLOYEES__

__Founder or CEO__

Still in the room for sales\. Feels the disconnect personally\. Makes the call to fix it\.

__100\-150 EMPLOYEES__

__VP Marketing or VP Sales__

Owns the number\. Watching pipeline stall and knows the story isn't working\.

__150\-200 EMPLOYEES__

__CMO or CRO__

GTM is broken cross\-functionally\. Needs someone external to cut through the internal noise\.

__CONTENT AUDIENCE VS CONSULTING BUYER__

__Consulting buyer__

Revenue\-accountable exec at a 50\-200 person B2B SaaS company\. Hires me to do the research and build the framework\.

__Content reader__

PMM or senior marketer at a similar company\. Reads The Narrative Pivot because I speak their frustration fluently\. Not the buyer, but the warm introduction — they forward my work upward\.

__WHO THEY ARE NOT__

- Pre\-PMF founders still figuring out product direction
- Companies without customers yet \(nothing to listen to\)
- Enterprise teams with a full PMM org and a formal research function
- Anyone who thinks this is a brand or design exercise

The Narrative Pivot  |  ICP Reference  |  Last updated March 2026

