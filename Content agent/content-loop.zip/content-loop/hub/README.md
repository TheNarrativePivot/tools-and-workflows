# Hub

Optional weekly signal notes. One file per week (e.g. 2026-W29.md) when Neera chooses to run one: things noticed in the discourse, PMA finds, audience questions, event takeaways. This layer is a supplement to the idea bank, not a requirement. If it goes quiet for a few weeks, nothing breaks.
